const settings = require('../settings');
const fs = require('fs');
const path = require('path');

async function helpCommand(sock, chatId, message) {
    const helpMessage = `
╔═════════════╗
   *🗿 ${settings.botName || 'MegaBot-MD'}*  
   Version: *${settings.version || '3.0.0'}*
   by ${settings.botOwner || 'LORD MEGA𓃵'}
   YT : ${global.ytch}
╚═════════════╝
> _*TILT FOR*_
*Available Commands:*

> ╔═════════╗
> ║      *CREATOR*
> ║      _*MEGA𓃵*_
> ╚═════════╝

╔═════════════╗
║ ➤                 dןǝɥ. ɹo nuǝɯ.⇦
║ ➤                                  ƃuᴉp.⇦
║ ➤                                  ǝʌᴉןɐ.⇦
║ ➤                           ʇxǝʇ < sʇʇ.⇦
║ ➤                               ɹǝuʍo.⇦
║ ➤                                   ǝʞoɾ.⇦
║ ➤                                ǝʇonb.⇦
║ ➤                                   ʇɔɐɟ.⇦
║ ➤                 ʎʇᴉɔ < ɹǝɥʇɐǝʍ.⇦
║ ➤                                 sʍǝu.⇦
║ ➤                         ʇxǝʇ < dʇʇɐ.⇦
║ ➤           ǝןʇᴉʇ_ƃuos < sɔᴉɹʎן.⇦
║ ➤              uoᴉʇsǝnb < ןןɐq8.⇦
║ ➤                         oɟuᴉdnorƃ.⇦
║ ➤              ɟɟɐʇs. ɹo suᴉɯpɐ.⇦
║ ➤                                       ʌʌ.⇦
║ ➤                ƃuɐן < ʇxǝʇ < ʇɹʇ.⇦
║ ➤                            ʞuᴉן < ss.⇦
║ ➤                                      pᴉɾ.⇦ 
║ ➤                                      lɹn.⇦
🌐 *ןuɐɹǝפ spuɐɯɯoƆ*   
╚═════════════╝

╔═════════════╗
║ ➤                     ɹǝsn@ uɐq.⇦
║ ➤             ɹǝsn@ ǝʇoɯoɹd.⇦
║ ➤               ɹǝsn@ ǝʇoɯǝp.⇦
║ ➤             sǝʇnuᴉɯ < ǝʇnɯ.⇦
║ ➤                           ǝʇnɯun.⇦
║ ➤ ןǝp. ɹo ǝʇǝןǝp.⇦
║ ➤                       ɹǝsn@ ʞɔᴉʞ.⇦
║ ➤              ɹǝsn@ sƃuᴉuɹɐʍ.⇦
║ ➤                     ɹǝsn@ uɹɐʍ.⇦
║ ➤                             ʞuᴉןᴉʇuɐ.⇦
║ ➤                    pɹoʍpɐqᴉʇuɐ.⇦
║ ➤                                 ɹɐǝןɔ.⇦
║ ➤                 ǝƃɐssǝɯ < ƃɐʇ.⇦
║ ➤                         ןןɐƃɐʇ.⇦
║ ➤                   uᴉɯpɐʇouƃɐʇ.⇦
║ ➤         ǝƃɐssǝɯ < ƃɐʇǝpᴉɥ.⇦
║ ➤                            ʇoqʇɐɥɔ.⇦
║ ➤                           ʞuᴉןʇǝsǝɹ.⇦
║ ➤               ɟɟo/uo < ƃɐʇᴉʇuɐ.⇦
║ ➤           ɟɟo/uo < ǝɯoɔןǝʍ.⇦
║ ➤           ɟɟo/uo < ǝʎqpooƃ.⇦
║ ➤ uoᴉʇdᴉɹɔsǝp < ɔsǝpƃʇǝs.⇦
║ ➤  ǝɯɐu ʍǝu < ǝɯɐuƃʇǝs.⇦
║ ➤ (ǝƃɐɯᴉ oʇ ʎןdǝɹ) ddƃʇǝs.⇦
°          👮‍♂️ *uᴉɯp∀ spuɐɯɯoƆ*  
╚═════════════╝
╔═════════════╗
║ ➤                             ɯou.⇦
║ ➤                            ǝʞod.⇦
║ ➤                               ʎɹɔ.⇦
║ ➤                             ssᴉʞ.⇦
║ ➤                               ʇɐd.⇦
║ ➤                              ƃnɥ.⇦
║ ➤                             ʞuᴉʍ.⇦
║ ➤                     ɯןɐdǝɔɐɟ.⇦
°                              🖼️ *ƎWINA*
╚═════════════╝
╔═════════════╗
║ ➤                                  ʇᴉƃ.⇦
║ ➤                              qnʇᴉƃ.⇦
║ ➤                                   ɔs.⇦
║ ➤                             ʇdᴉɹɔs.⇦
║ ➤                               odǝɹ.⇦
°               💻 *dnɐɯɯoƆ qnʇᴉפ*
╚═════════════╝
╔═════════════╗
║ ➤               ʎɹʇunoɔ < sǝᴉd.⇦
║ ➤                             ɐuᴉɥɔ.⇦
║ ➤                      ɐᴉsǝuopuᴉ.⇦
║ ➤                             uɐdɐɾ.⇦
║ ➤                             ɐǝɹoʞ.⇦
║ ➤                              qɐɾᴉɥ.⇦
°                                   🖼️ *SƎᴉԀ*
╚═════════════╝
╔═════════════╗
║ ➤                              ʇɹɐǝɥ.⇦
║ ➤                             ʎuɹoɥ.⇦
║ ➤                             ǝןɔɹᴉɔ.⇦
║ ➤                                ʇqƃן.⇦
║ ➤                              ǝɔᴉןoן.⇦
║ ➤                    pᴉdnʇs-os-ʇᴉ.⇦
║ ➤                      pɹɐɔǝɯɐu.⇦
║ ➤                          ʎɐʍƃoo.⇦
║ ➤                              ʇǝǝʍʇ.⇦
║ ➤                    ʇuǝɯɯoɔʇʎ.⇦
║ ➤                        ǝpɐɹɯoɔ.⇦
║ ➤                                 ʎɐƃ.⇦
║ ➤                              ssɐןƃ.⇦
║ ➤                       ןᴉɐɾ.⇦
║ ➤                           pǝssɐd.⇦
║ ➤                        pǝɹǝƃƃᴉɹʇ.⇦
°                                   🧩 *ƆSᴉW*
╚═════════════╝
╔═════════════╗
║ ➤             ʇxǝʇ < ɔᴉןןɐʇǝɯ.⇦
║ ➤                      ʇxǝʇ < ǝɔᴉ.⇦
║ ➤                  ʇxǝʇ < ʍous.⇦
║ ➤        ʇxǝʇ < ǝʌᴉssǝɹdɯᴉ.⇦
║ ➤                ʇxǝʇ < xᴉɹʇɐɯ.⇦
║ ➤                   ʇxǝʇ < ʇɥƃᴉן.⇦
║ ➤                   ʇxǝʇ < uǝou.⇦
║ ➤                  ʇxǝʇ < ןᴉʌǝp.⇦
║ ➤               ʇxǝʇ < ǝןdɹnd.⇦
║ ➤              ʇxǝʇ < ɹǝpnuɥʇ.⇦
║ ➤               ʇxǝʇ < sǝʌɐǝן.⇦
║ ➤                   ʇxǝʇ < 7191.⇦
║ ➤                ʇxǝʇ < ɐuǝɹɐ.⇦
║ ➤               ʇxǝʇ < ɹǝʞɔɐɥ.⇦
║ ➤                   ʇxǝʇ < puɐs.⇦
║ ➤          ʇxǝʇ < ʞuᴉdpʞɔɐןq.⇦
║ ➤                   ʇxǝʇ < ɥɔʇᴉןƃ.⇦
║ ➤                       ʇxǝʇ < ǝɹᴉɟ.⇦
°                         🔤 *ɹǝʞɐɯʇxǝ⊥*
╚═════════════╝

╔═════════════╗
║ ➤     ǝʇɐʌᴉɹd/ɔᴉןqnd < ǝpoɯ.⇦
║ ➤                     uoᴉssǝsɹɐǝןɔ.⇦
║ ➤                          ǝʇǝןǝpᴉʇuɐ.⇦
║ ➤                            dɯʇɹɐǝןɔ.⇦
║ ➤                               ǝʇɐpdn.⇦
║ ➤                             sƃuᴉʇʇǝs.⇦
║ ➤     ǝƃɐɯᴉ oʇ ʎןdǝɹ < ddʇǝs.⇦
║ ➤         ɟɟo/uo < ʇɔɐǝɹǝɹoʇnɐ.⇦
║ ➤          ɟɟo/uo < snʇɐʇsoʇnɐ.⇦
║ ➤ ɟɟo/uo < ʇɔɐǝɹ snʇɐʇsoʇnɐ.⇦
║ ➤          ɟɟo/uo < ƃuᴉdʎʇoʇnɐ.⇦
║ ➤             ɟɟo/uo < pɐǝɹoʇnɐ.⇦
║ ➤               ɟɟo/uo < ןןɐɔᴉʇuɐ.⇦
║ ➤ snʇɐʇs/ɟɟo/uo < ɹǝʞɔoןqɯd.⇦
║ ➤ ʇxǝʇ < ƃsɯʇǝs ɹǝʞɔoןqɯd.⇦
║ ➤ ƃsɯ oʇ ʎןdǝɹ < uoᴉʇuǝɯʇǝs.⇦
║ ➤              ɟɟo/uo < uoᴉʇuǝɯ.⇦
°           🔒 *ɹǝuʍO spuɐɯɯoƆ*  
╚═════════════╝

╔═════════════╗
║ ➤                     ǝƃɐɯᴉ < ɹnןq.⇦
║ ➤ ɹǝʞɔᴉʇs oʇ ʎןdǝɹ < ǝƃɐɯᴉs.⇦
║ ➤   ǝƃɐɯᴉ oʇ ʎןdǝɹ < ɹǝʞɔᴉʇs.⇦
║ ➤                          ƃqǝʌoɯǝɹ.⇦
║ ➤                                ᴉuᴉɯǝɹ.⇦
║ ➤      ǝƃɐɯᴉ oʇ ʎןdǝɹ < doɹɔ.⇦
║ ➤                  ʞuᴉן < ɹǝʞɔᴉʇsƃʇ.⇦
║ ➤                                ǝɯǝɯ.⇦
║ ➤              ǝɯɐuʞɔɐd < ǝʞɐʇ.⇦
║ ➤ 2ɾɯǝ<+>1ɾɯǝ < xᴉɯᴉɾoɯǝ.⇦
║ ➤                  ʞuᴉן ɐʇsuᴉ < sƃᴉ.⇦
║ ➤                ʞuᴉן ɐʇsuᴉ < ɔsƃᴉ.⇦
🎨 *ɹǝʞɔᴉʇS/ǝƃɐɯI spuɐɯɯoƆ*  
╚═════════════╝

╔═════════════╗
║ ➤          ɹǝsn@ ǝoʇɔɐʇɔᴉʇ.⇦
║ ➤                     uɐɯƃuɐɥ.⇦
║ ➤              ɹǝʇʇǝן < ssǝnƃ.⇦
║ ➤                             ɐᴉʌᴉɹʇ.⇦
║ ➤         ɹǝʍsuɐ < ɹǝʍsuɐ.⇦
║ ➤                              ɥʇnɹʇ.⇦
║ ➤                              ǝɹɐp.⇦
°           🎮 *ǝɯɐפ spuɐɯɯoƆ*  
╚═════════════╝

╔═════════════╗
║ ➤              uoᴉʇsǝnb < ʇdƃ.⇦
║ ➤        uoᴉʇsǝnb < ᴉuᴉɯǝƃ.⇦
║ ➤        ʇdɯoɹd < ǝuᴉƃɐɯᴉ.⇦
║ ➤                ʇdɯoɹd < xnןɟ.⇦
║ ➤               ʇdɯoɹd < ɐɹos.⇦
°                 🤖 *I∀ spuɐɯɯoƆ*  
╚═════════════╝

╔═════════════╗
║ ➤     ɹǝsn@ ʇuǝɯᴉןdɯoɔ.⇦
║ ➤                ɹǝsn@ ʇןnsuᴉ.⇦
║ ➤                                ʇɹᴉןɟ.⇦
║ ➤                         ᴉɹɐʎɐɥs.⇦
║ ➤                    ʇɥƃᴉupoob.⇦
║ ➤                        ʎɐpǝsoɹ.⇦
║ ➤          ɹǝsn@ ɹǝʇɔɐɹɐɥɔ.⇦
║ ➤              ɹǝsn@ pǝʇsɐʍ.⇦
║ ➤                   ɹǝsn@ dᴉɥs.⇦
║ ➤                  ɹǝsn@ dɯᴉs.⇦
║ ➤       ʇxǝʇ [ɹǝsn@] pᴉdnʇs.⇦
°               🎯 *unℲ spuɐɯɯoƆ*  
╚═════════════╝

╔═════════════╗
║ ➤      ǝɯɐu_ƃuos < ʎɐןd.⇦
║ ➤     ǝɯɐu_ƃuos < ƃuos.⇦
║ ➤          . ʎɹǝnb < ʎɟᴉʇods.⇦
║ ➤          ʞuᴉן < ɯɐɹƃɐʇsuᴉ.⇦
║ ➤            ʞuᴉן < ʞooqǝɔɐɟ.⇦
║ ➤                   ʞuᴉן < ʞoʇʞᴉʇ.⇦
║ ➤      ǝɯɐu ƃuos < oǝpᴉʌ.⇦
║ ➤                ʞuᴉןl   > 4dɯʇʎ.⇦
°                     📥 *ɹǝpɐoןuʍoᗡ*  
╚═════════════╝
> LORDMEGA NULL CHANNEL:`;

    try {
        const imagePath = path.join(__dirname, '../assets/bot_image.jpg');
        
        if (fs.existsSync(imagePath)) {
            const imageBuffer = fs.readFileSync(imagePath);
            
            await sock.sendMessage(chatId, {
                image: imageBuffer,
                caption: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '2120363161513685998@newsletter',
                        newsletterName: 'MegaBot MD',
                        serverMessageId: -1
                    }
                }
            },{ quoted: message });
        } else {
            console.error('Bot image not found at:', imagePath);
            await sock.sendMessage(chatId, { 
                text: helpMessage,
                contextInfo: {
                    forwardingScore: 1,
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                        newsletterJid: '2120363161513685998@newsletter',
                        newsletterName: 'MegaBot MD by Mr Unique Hacker',
                        serverMessageId: -1
                    } 
                }
            });
        }
    } catch (error) {
        console.error('Error in help command:', error);
        await sock.sendMessage(chatId, { text: helpMessage });
    }
}

module.exports = helpCommand;